 function Produit(id, lilte, prix) {
  	this.id= id;
  	this.prix= prix;
  	this.lilte= lilte;
  	this.toString= function() {
		return this.lilte + " "+ prix;
  	}
  }

  var cards= new Array();
  cards.push(new Produit(1, "arraw", 2500));
  cards.push(new Produit(2, "farine de riz", 2000));
  cards.push(new Produit(3, "sankal", 1500));
  cards.push(new Produit(4, "thiakry", 1000));
  cards.push(new Produit(5, "blé", 2000));
  cards.push(new Produit(6, "fonio", 3500));
  cards.push(new Produit(7, "farine de mais", 3500));
  cards.push(new Produit(8, "pagnet complet", 45000));
  cards.push(new Produit(9, "pagnet", 35000));
  
  var panier= new Array();

  

  function remplirCards() {
        var card= document.getElementById('cat');
  	for (var i in catalogue) {
  	    var e= document.createElement("option");
  	    e.value=i;
            var txt= document.createTextNode(catalogue[i].lilte);
            e.appendChild(txt);
  	    cat.appendChild(e);
  	}
  }

function ajouterCase(parent, txt) {
  var e= document.createElement;
  e.appendChild(document.createTextNode(txt));
  parent.appendChild(e);
}

function calculerTotal() {
  var total= 0;
  for (var p in panier) {
  	total+= panier[p].prix;
  }
  return total;
}

function ajouter() {
    	var card= document.getElementById('cat');
  	var sel= card.options[cat.selectedIndex].value;
  	var prod= catalogue[sel];
  	panier.push(prod);
  	var ligne= document.createElement;
        ajouterCase(ligne,prod.lilte);
        ajouterCase(ligne,prod.prix);
  	document.getElementById("pan").appendChild(ligne);
  	document.getElementById("total").innerHTML= calculerTotal();
}
